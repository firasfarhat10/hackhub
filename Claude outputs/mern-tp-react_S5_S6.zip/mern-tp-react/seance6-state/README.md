# Séance 6 – TechStore : useContext et Redux Toolkit

```bash
npm install
npm run dev
```

- `src/context/ThemeContext.jsx` : thème clair / sombre (Context API), persistant
- `src/redux/cartSlice.js` : slice du panier (ajout, retrait, vidage, code promo, stock, persistance)
- `src/redux/store.js` : store central (`configureStore`)
- `src/components/` : `Navbar` (useSelector ciblé), `ProductList` / `ProductCard` (dispatch, stock), `Cart` (quantités, code promo)

Code promo de test : `POLY2027`
