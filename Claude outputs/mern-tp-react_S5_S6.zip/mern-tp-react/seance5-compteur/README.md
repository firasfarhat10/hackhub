# Séance 5 – Compteur React (useState / useEffect)

```bash
npm install
npm run dev
```

- `src/components/Header.jsx` : composant fonctionnel avec props
- `src/components/Counter.jsx` : état réactif, pas d'incrémentation, historique, bornes ±50, persistance et contrôle clavier
- `src/components/AutoTimer.jsx` : `setInterval` géré par `useEffect` avec fonction de nettoyage
