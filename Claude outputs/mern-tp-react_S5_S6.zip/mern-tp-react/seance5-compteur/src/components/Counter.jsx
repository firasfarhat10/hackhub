import { useState, useEffect } from 'react';

// Défi 1 : bornes du compteur
const MAX = 50;
const MIN = -50;

// Clés du localStorage
const CLE_VALEUR = 'mon_compteur_valeur';
const CLE_HISTORIQUE = 'mon_compteur_historique';

// Lecture sécurisée au démarrage (valeur absente ou corrompue -> valeur par défaut)
const lireValeur = () => {
  const sauvegarde = localStorage.getItem(CLE_VALEUR);
  const nombre = sauvegarde !== null ? parseInt(sauvegarde, 10) : 0;
  return Number.isNaN(nombre) ? 0 : nombre;
};

const lireHistorique = () => {
  try {
    const sauvegarde = localStorage.getItem(CLE_HISTORIQUE);
    const tableau = sauvegarde !== null ? JSON.parse(sauvegarde) : [];
    return Array.isArray(tableau) ? tableau : [];
  } catch {
    return [];
  }
};

export default function Counter() {
  // Initialisation paresseuse : la fonction n'est exécutée qu'au premier rendu
  const [count, setCount] = useState(lireValeur);
  const [step, setStep] = useState(1);
  const [message, setMessage] = useState('Aucun clic pour le moment');
  const [alerte, setAlerte] = useState(false);
  const [totalClics, setTotalClics] = useState(0);
  const [historique, setHistorique] = useState(lireHistorique);

  // Ajoute (ou retire) "delta" en respectant les bornes
  const changer = (delta) => {
    const nouveauCompte = count + delta;

    if (nouveauCompte > MAX) {
      setMessage(`Seuil maximal de ${MAX} atteint !`);
      setAlerte(true);
      return;
    }
    if (nouveauCompte < MIN) {
      setMessage(`Seuil minimal de ${MIN} atteint !`);
      setAlerte(true);
      return;
    }

    setCount(nouveauCompte);
    setMessage(delta > 0 ? 'Ajout de ' + delta : 'Retrait de ' + -delta);
    setAlerte(false);
    setTotalClics(totalClics + 1);
    setHistorique([...historique, (delta > 0 ? '+' : '') + delta]); // nouveau tableau
  };

  const handleIncrement = () => changer(step);
  const handleDecrement = () => changer(-step);

  const handleReset = () => {
    setCount(0);
    setMessage('Remise a zero');
    setAlerte(false);
    setTotalClics(totalClics + 1);
    setHistorique([]);
  };

  // Couleur selon le signe du compteur
  const getStyleClass = () => {
    if (count > 0) return 'counter-display positive';
    if (count < 0) return 'counter-display negative';
    return 'counter-display zero';
  };

  // EFFET A : titre de l'onglet
  useEffect(() => {
    document.title = 'Compteur : ' + count;
  }, [count]);

  // EFFET B : sauvegarde de la valeur
  useEffect(() => {
    localStorage.setItem(CLE_VALEUR, count.toString());
  }, [count]);

  // Défi 2 : sauvegarde de l'historique (tableau -> chaîne JSON)
  useEffect(() => {
    localStorage.setItem(CLE_HISTORIQUE, JSON.stringify(historique));
  }, [historique]);

  // Défi 3 : flèches du clavier, avec nettoyage de l'écouteur
  useEffect(() => {
    const handleKeyDown = (e) => {
      // Sur la liste déroulante, les flèches servent à changer le pas
      if (e.target.tagName === 'SELECT') return;

      if (e.key === 'ArrowUp') {
        e.preventDefault(); // évite le défilement de la page
        handleIncrement();
      } else if (e.key === 'ArrowDown') {
        e.preventDefault();
        handleDecrement();
      }
    };

    window.addEventListener('keydown', handleKeyDown);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [handleIncrement, handleDecrement]); // on se réabonne avec les fonctions à jour

  return (
    <div className="counter-card">
      <div className={getStyleClass()}>{count}</div>

      <div className="btn-group">
        <button className="btn btn-dec" onClick={handleDecrement} disabled={count - step < MIN}>
          -{step}
        </button>
        <button className="btn btn-reset" onClick={handleReset}>
          Reset
        </button>
        <button className="btn btn-inc" onClick={handleIncrement} disabled={count + step > MAX}>
          +{step}
        </button>
      </div>

      <div className="step-control">
        <label htmlFor="pas">Pas d'incrementation :</label>
        <select id="pas" value={step} onChange={(e) => setStep(parseInt(e.target.value, 10))}>
          <option value="1">1</option>
          <option value="2">2</option>
          <option value="5">5</option>
          <option value="10">10</option>
        </select>
      </div>

      <div className="history-card">
        <p className={alerte ? 'alerte' : ''}>
          <strong>Derniere action :</strong> {message}
        </p>
        <p>
          <strong>Total des clics :</strong> {totalClics}
        </p>
        {historique.length > 0 && (
          <p>
            <strong>Historique :</strong> {historique.join(', ')}
          </p>
        )}
      </div>

      <p className="hint">Astuce : fleches du clavier haut / bas pour piloter le compteur</p>
    </div>
  );
}
