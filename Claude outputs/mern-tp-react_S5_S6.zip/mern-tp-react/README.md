# TP MERN – Séances 5 et 6 (React)

Travaux pratiques du module MERN Stack – École Polytechnique de Sousse (2026-2027).
Auteur : Firas Farhat

| Dossier | Séance | Contenu |
|---|---|---|
| [`seance5-compteur`](seance5-compteur) | 5 | React + Vite, JSX, `useState`, `useEffect` : compteur interactif, historique, persistance `localStorage`, chronomètre avec nettoyage, contrôle au clavier |
| [`seance6-state`](seance6-state) | 6 | État global : thème clair / sombre avec `useContext`, panier e-commerce avec Redux Toolkit (`createSlice`, `configureStore`, `useSelector`, `useDispatch`), code promo, gestion du stock |

## Lancer un projet

```bash
cd seance5-compteur   # ou seance6-state
npm install
npm run dev           # http://localhost:5173
```

Prérequis : Node.js 20.19 ou plus récent.

## Défis réalisés

**Séance 5**
1. Bornes du compteur entre -50 et +50 avec message d'alerte et boutons désactivés
2. Historique des actions sauvegardé dans le `localStorage` et restauré après F5
3. Pilotage du compteur avec les flèches du clavier (écouteur retiré dans le nettoyage de `useEffect`)

**Séance 6**
1. Panier persistant dans le `localStorage` (totaux recalculés au démarrage)
2. Code promo `POLY2027` : 20 % de remise, recalculée à chaque modification du panier
3. Stock limité à 3 par produit : bouton « Rupture de Stock » désactivé, règle aussi appliquée dans le reducer
